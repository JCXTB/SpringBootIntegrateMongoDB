package com.mongoDB.mongo.eneity;

import lombok.Data;

@Data
public class Student {
    private String name;
    private Integer age;
    private String classId;

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", classId='" + classId + '\'' +
                '}';
    }
}
