package com.mongoDB.mongo.controller;

import com.mongoDB.mongo.service.MongoOperationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/mongo")
public class MongoOperationControlle {
    @Autowired
    private MongoOperationService mongoOperationService;

    @RequestMapping("/test")
    public String test(){
        return mongoOperationService.test();
    }
}
