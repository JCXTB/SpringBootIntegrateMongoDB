package com.mongoDB.mongo.dao;

import com.mongoDB.mongo.eneity.Grade;
import com.mongoDB.mongo.eneity.Student;
import com.mongoDB.mongo.eneity.StudentInfo;

import java.util.List;

public interface BasicsOperationDAO {
    String test();
    void mongoSaveStudent(Student student);
    void mongoSaveGrade(Grade grade);
    void mongoDeleteStudent(String studentName);
    void mongoUpdateStudent(Student student);
    Student mongoSingleTableSeleteStudent(String studentName);
    List<Student> mongoPagingSeleteStudent(Integer pageIndex, Integer pageSize);
    List<StudentInfo> mongoCompositeSelete();
}
