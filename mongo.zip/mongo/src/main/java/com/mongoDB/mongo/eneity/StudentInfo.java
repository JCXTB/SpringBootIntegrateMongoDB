package com.mongoDB.mongo.eneity;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
public class StudentInfo {
    private String name;
    private Integer age;
    @Field("_id")
    private String id;
    @Field("grade_info_id")
    private String id2;
}
