package com.mongoDB.mongo.eneity;

import lombok.Data;

@Data
public class Grade {
    private String id;
    private String name;
}
